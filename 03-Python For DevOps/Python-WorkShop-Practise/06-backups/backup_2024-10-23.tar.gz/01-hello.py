# print("Welcome to Python for Devops!")

# user input 
"""name = input("What is your name? ")
print(f"Hello, {name}!")"""


# yahan par input wala name print nai hoga Ali Raza print hoga , 
# kyun k variable change ho sakte hai
# constant change nai hota, variable change ho sakta hai
"""name = input("What is your name? ")
name = "Ali Raza"
print(f"Hello, {name}!")
"""

