num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

print(type(num1))
print(type(num2))

sum = num1 + num2
print("The sum of the two numbers is:",sum)

diff = num1 - num2
print("The difference of the two numbers is:", diff)

prod = num1 * num2
print("The Products of the two numbers is:", prod)

div = num1 / num2
print("The division of the two numbers is:", div)
